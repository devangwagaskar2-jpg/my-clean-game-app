import React, { useState } from 'react';
import {
  Alert,
  Image,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { Feather } from '@expo/vector-icons';
import { useColors } from '@/hooks/useColors';
import { useGame } from '@/state/GameContext';
import { FORMATION_NAMES, type FormationKey } from '@/game/engine';
import { AdMobTestBanner } from '@/components/AdMobTestBanner';

export default function HomeScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { save, beginDraft, hydrated, saveError, dismissSaveError, setUsername } = useGame();
  const [formation, setFormation] = useState<FormationKey>('4-3-3');
  const [editingName, setEditingName] = useState(false);
  const [nameDraft, setNameDraft] = useState(save.username);
  const topInset = Platform.OS === 'web' ? 67 : insets.top;

  const launchDraft = (mode: 'quick' | 'daily') => {
    const start = () => {
      beginDraft(mode === 'daily' ? '4-3-3' : formation, mode);
      router.push('/draft');
    };
    if (save.currentDraft && save.currentDraft.picks.length < 11) {
      Alert.alert('Start a new draft?', 'Your unfinished draft is saved. Starting a new one replaces it.', [
        { text: 'Keep drafting', style: 'cancel' },
        { text: 'Start new draft', onPress: start },
      ]);
      return;
    }
    start();
  };

  return (
    <View style={[styles.screen, { backgroundColor: colors.background }]}>
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingTop: topInset + 12, paddingBottom: (Platform.OS === 'web' ? 34 : insets.bottom) + 104 }}
      >
        <View style={styles.header}>
          <View style={styles.brandRow}>
            <Image source={require('@/assets/images/icon.png')} style={styles.logo} />
            <View>
              <Text style={styles.eyebrow}>ULTIMATE FOOTBALL</Text>
              <Text style={styles.brandTitle}>DRAFT</Text>
            </View>
          </View>
          <View style={[styles.coinPill, { borderColor: colors.border }]}>
            <Feather name="hexagon" size={15} color={colors.accent} />
            <Text style={styles.coinValue}>{save.coins.toLocaleString()}</Text>
          </View>
        </View>

        {saveError ? (
          <Pressable onPress={dismissSaveError} style={styles.saveNotice}>
            <Feather name="alert-circle" color={colors.accent} size={16} />
            <Text style={styles.saveNoticeText}>{saveError}</Text>
            <Feather name="x" color={colors.mutedForeground} size={16} />
          </Pressable>
        ) : null}

        <LinearGradient colors={['#263C24', '#17231A', '#131714']} style={styles.hero}>
          <View style={styles.heroTop}>
            <View style={styles.liveTag}><View style={styles.liveDot} /><Text style={styles.liveText}>YOUR CLUB</Text></View>
            <Text style={styles.heroRecord}>{save.wins}W · {save.draws}D · {save.losses}L</Text>
          </View>
          <Text style={styles.heroTitle}>Build a side{'\n'}worth remembering.</Text>
          <Text style={styles.heroCopy}>Pick your formation. Make every selection count.</Text>
          <View style={styles.managerRow}>
            <View style={styles.managerAvatar}><Feather name="user" size={18} color={colors.primary} /></View>
            {editingName ? (
              <View style={styles.nameEditor}>
                <TextInput
                  value={nameDraft}
                  onChangeText={setNameDraft}
                  maxLength={20}
                  placeholder="Manager name"
                  placeholderTextColor={colors.mutedForeground}
                  style={styles.nameInput}
                  returnKeyType="done"
                  onSubmitEditing={() => {
                    if (nameDraft.trim()) {
                      setUsername(nameDraft);
                    }
                    setEditingName(false);
                  }}
                />
                <Pressable
                  accessibilityRole="button"
                  testID="save-manager-name"
                  onPress={() => {
                    if (nameDraft.trim()) {
                      setUsername(nameDraft);
                    }
                    setEditingName(false);
                  }}
                  style={styles.saveNameButton}
                >
                  <Feather name="check" size={16} color={colors.primaryForeground} />
                </Pressable>
              </View>
            ) : (
              <Pressable
                onPress={() => {
                  setNameDraft(save.username);
                  setEditingName(true);
                }}
                style={styles.managerName}
              >
                <Text style={styles.managerLabel}>MANAGER</Text>
                <Text style={styles.managerValue}>{save.username}</Text>
              </Pressable>
            )}
            <View style={styles.heroStat}>
              <Text style={styles.heroStatValue}>{save.activeSquad?.rating ?? '—'}</Text>
              <Text style={styles.heroStatLabel}>BEST XI</Text>
            </View>
          </View>
        </LinearGradient>

        <View style={styles.sectionHeading}>
          <Text style={styles.sectionTitle}>Choose your shape</Text>
          <Text style={styles.sectionHint}>11 positions · one squad</Text>
        </View>
        <View style={styles.formations}>
          {FORMATION_NAMES.map((item) => {
            const selected = formation === item;
            return (
              <Pressable
                key={item}
                accessibilityRole="button"
                accessibilityState={{ selected }}
                testID={`formation-${item}`}
                onPress={() => setFormation(item)}
                style={[
                  styles.formationChip,
                  { borderColor: selected ? colors.primary : colors.border, backgroundColor: selected ? '#263B20' : colors.card },
                ]}
              >
                <Text style={[styles.formationText, { color: selected ? colors.primary : colors.foreground }]}>{item}</Text>
              </Pressable>
            );
          })}
        </View>

        {save.currentDraft && save.currentDraft.picks.length < 11 ? (
          <Pressable
            testID="resume-draft"
            onPress={() => router.push('/draft')}
            style={({ pressed }) => [styles.resumeButton, { borderColor: colors.accent, opacity: pressed ? 0.8 : 1 }]}
          >
            <Feather name="play" size={17} color={colors.accent} />
            <Text style={styles.resumeText}>RESUME DRAFT · {save.currentDraft.picks.length}/11 PICKS</Text>
            <Feather name="arrow-up-right" size={16} color={colors.accent} />
          </Pressable>
        ) : null}

        <Pressable
          accessibilityRole="button"
          testID="start-draft"
          onPress={() => launchDraft('quick')}
          style={({ pressed }) => [styles.startButton, { opacity: pressed ? 0.8 : 1 }]}
        >
          <LinearGradient colors={['#C9FF72', '#A7EC42']} style={styles.startGradient}>
            <View style={styles.startIcon}><Feather name="zap" size={18} color="#14200D" /></View>
            <View style={styles.startCopy}>
              <Text style={styles.startTitle}>START A DRAFT</Text>
              <Text style={styles.startSubtitle}>Build your 11 · play for coins</Text>
            </View>
            <Feather name="arrow-right" size={20} color="#14200D" />
          </LinearGradient>
        </Pressable>

        <Pressable
          accessibilityRole="button"
          testID="daily-draft"
          onPress={() => launchDraft('daily')}
          style={({ pressed }) => [styles.dailyButton, { borderColor: colors.border, opacity: pressed ? 0.78 : 1 }]}
        >
          <View style={styles.dailyIcon}><Feather name="calendar" color={colors.accent} size={18} /></View>
          <View style={{ flex: 1 }}>
            <Text style={styles.dailyTitle}>DAILY CHALLENGE</Text>
            <Text style={styles.dailySubtitle}>Today’s player pool is seeded to the date</Text>
          </View>
          <Feather name="chevron-right" size={18} color={colors.mutedForeground} />
        </Pressable>

        <View style={styles.statsRow}>
          <Stat label="DRAFTS" value={save.draftsCompleted} />
          <Stat label="MATCHES" value={save.matchesPlayed} />
          <Stat label="COLLECTION" value={save.collection.length} />
        </View>
        {save.lastMatch ? (
          <Pressable style={styles.lastMatch} onPress={() => router.push('/match')}>
            <View>
              <Text style={styles.lastMatchLabel}>LAST RESULT</Text>
              <Text style={styles.lastMatchScore}>{save.lastMatch.homeGoals} — {save.lastMatch.awayGoals}</Text>
            </View>
            <Text style={styles.lastMatchOpponent}>vs {save.lastMatch.opponent}</Text>
            <Feather name="chevron-right" size={17} color={colors.mutedForeground} />
          </Pressable>
        ) : null}
        <AdMobTestBanner />
        {!hydrated ? <Text style={styles.loadingText}>Loading your saved club…</Text> : null}
      </ScrollView>
    </View>
  );
}

function Stat({ label, value }: { label: string; value: number }) {
  return (
    <View style={styles.statCard}>
      <Text style={styles.statNumber}>{value}</Text>
      <Text style={styles.statTitle}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  header: { paddingHorizontal: 20, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 19 },
  brandRow: { flexDirection: 'row', alignItems: 'center', gap: 11 },
  logo: { width: 42, height: 42, borderRadius: 13 },
  eyebrow: { color: '#A9B2A6', fontSize: 9, letterSpacing: 1.6, fontWeight: '800' },
  brandTitle: { color: '#F5F6EF', fontSize: 20, fontWeight: '900', letterSpacing: 0.6 },
  coinPill: { flexDirection: 'row', alignItems: 'center', gap: 7, backgroundColor: '#171B17', paddingHorizontal: 12, paddingVertical: 9, borderWidth: 1, borderRadius: 16 },
  coinValue: { color: '#F5F6EF', fontSize: 14, fontWeight: '800' },
  saveNotice: { marginHorizontal: 20, marginBottom: 14, padding: 12, backgroundColor: '#292015', borderRadius: 12, flexDirection: 'row', gap: 9, alignItems: 'center' },
  saveNoticeText: { color: '#E1D0A5', fontSize: 11, flex: 1, lineHeight: 16 },
  hero: { marginHorizontal: 20, borderRadius: 23, padding: 20, borderWidth: 1, borderColor: '#3D5637', overflow: 'hidden' },
  heroTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  liveTag: { flexDirection: 'row', alignItems: 'center', gap: 7, backgroundColor: 'rgba(181,255,75,0.11)', borderRadius: 12, paddingHorizontal: 10, paddingVertical: 6 },
  liveDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: '#B5FF4B' },
  liveText: { color: '#C2F77D', fontSize: 9, fontWeight: '900', letterSpacing: 1.1 },
  heroRecord: { color: '#D1D9C8', fontSize: 10, fontWeight: '700' },
  heroTitle: { color: '#F5F6EF', fontSize: 29, fontWeight: '900', lineHeight: 33, marginTop: 21, letterSpacing: -0.7 },
  heroCopy: { color: '#C1C9BD', fontSize: 12, marginTop: 8 },
  managerRow: { flexDirection: 'row', alignItems: 'center', marginTop: 23, paddingTop: 15, borderTopWidth: 1, borderTopColor: 'rgba(255,255,255,0.11)', gap: 9 },
  managerAvatar: { width: 35, height: 35, borderRadius: 12, backgroundColor: '#20321F', justifyContent: 'center', alignItems: 'center' },
  managerName: { flex: 1 },
  managerLabel: { color: '#9FAA97', fontSize: 8, fontWeight: '800', letterSpacing: 1 },
  managerValue: { color: '#F2F5EA', fontSize: 12, fontWeight: '800', marginTop: 2 },
  heroStat: { alignItems: 'flex-end' },
  heroStatValue: { color: '#C5F77B', fontSize: 22, fontWeight: '900' },
  heroStatLabel: { color: '#9FAA97', fontSize: 8, fontWeight: '800', letterSpacing: 0.8 },
  nameEditor: { flex: 1, flexDirection: 'row', alignItems: 'center', gap: 6 },
  nameInput: { flex: 1, height: 36, color: '#F2F5EA', fontSize: 12, borderWidth: 1, borderColor: '#51614B', borderRadius: 9, paddingHorizontal: 9 },
  saveNameButton: { width: 34, height: 34, backgroundColor: '#B5FF4B', borderRadius: 10, justifyContent: 'center', alignItems: 'center' },
  sectionHeading: { paddingHorizontal: 20, marginTop: 25, marginBottom: 12, flexDirection: 'row', alignItems: 'baseline', justifyContent: 'space-between' },
  sectionTitle: { color: '#F0F3E9', fontSize: 17, fontWeight: '800' },
  sectionHint: { color: '#899187', fontSize: 10 },
  formations: { paddingHorizontal: 20, flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  formationChip: { paddingHorizontal: 13, paddingVertical: 9, borderWidth: 1, borderRadius: 12 },
  formationText: { fontSize: 11, fontWeight: '800' },
  resumeButton: { marginHorizontal: 20, marginTop: 17, padding: 13, borderWidth: 1, borderRadius: 14, flexDirection: 'row', alignItems: 'center', gap: 9 },
  resumeText: { color: '#E9D698', fontSize: 10, fontWeight: '900', letterSpacing: 0.45, flex: 1 },
  startButton: { marginHorizontal: 20, marginTop: 14, borderRadius: 16, overflow: 'hidden' },
  startGradient: { padding: 15, flexDirection: 'row', alignItems: 'center', gap: 12 },
  startIcon: { width: 35, height: 35, borderRadius: 11, backgroundColor: 'rgba(20,32,13,0.12)', justifyContent: 'center', alignItems: 'center' },
  startCopy: { flex: 1 },
  startTitle: { color: '#15200D', fontSize: 13, fontWeight: '900', letterSpacing: 0.7 },
  startSubtitle: { color: '#314324', fontSize: 10, marginTop: 3, fontWeight: '600' },
  dailyButton: { marginHorizontal: 20, marginTop: 10, padding: 13, backgroundColor: '#151A17', borderWidth: 1, borderRadius: 15, flexDirection: 'row', alignItems: 'center', gap: 11 },
  dailyIcon: { width: 35, height: 35, backgroundColor: '#2C281B', borderRadius: 11, justifyContent: 'center', alignItems: 'center' },
  dailyTitle: { color: '#E7D397', fontSize: 11, fontWeight: '900', letterSpacing: 0.6 },
  dailySubtitle: { color: '#9CA498', fontSize: 10, marginTop: 4 },
  statsRow: { flexDirection: 'row', gap: 9, paddingHorizontal: 20, marginTop: 18 },
  statCard: { flex: 1, paddingVertical: 13, paddingHorizontal: 12, backgroundColor: '#151A17', borderRadius: 15, borderWidth: 1, borderColor: '#252D26' },
  statNumber: { color: '#F2F5EA', fontSize: 20, fontWeight: '900' },
  statTitle: { color: '#99A195', fontSize: 8, fontWeight: '800', letterSpacing: 0.7, marginTop: 4 },
  lastMatch: { marginHorizontal: 20, marginTop: 12, padding: 14, backgroundColor: '#151A17', borderRadius: 14, flexDirection: 'row', alignItems: 'center', gap: 12 },
  lastMatchLabel: { color: '#9AA396', fontSize: 8, fontWeight: '800', letterSpacing: 0.7 },
  lastMatchScore: { color: '#F2F5EA', fontSize: 17, fontWeight: '900', marginTop: 3 },
  lastMatchOpponent: { flex: 1, color: '#B6BFB2', fontSize: 11 },
  loadingText: { textAlign: 'center', color: '#929B90', fontSize: 11, marginTop: 18 },
});
import { InterstitialAd, AdEventType, TestIds } from 'react-native-google-mobile-ads';
const adUnitId = 'ca-app-pub-3940256099942544/1033173712';
const interstitial = InterstitialAd.createForAdRequest(adUnitId, {
  keywords: ['fashion', 'clothing'],
});

export const triggerFullScreenAd = () => {
  try {
    interstitial.load();
    interstitial.addAdEventListener(AdEventType.LOADED, () => {
      interstitial.show();
    });
  } catch (error) {
    console.error("AdMob Error:", error);
  }
};